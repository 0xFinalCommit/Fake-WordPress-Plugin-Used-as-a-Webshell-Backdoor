<?php
/**
 * ZEDD CLEANER - MINIMAL
 * 1. Cari wp-config.php otomatis (search upward)
 * 2. Hapus semua folder plugin file manager WP
 * 3. Tambahkan define hardening ke wp-config.php
 */
set_time_limit(120);
error_reporting(0);

// 📦 Daftar lengkap folder plugin file manager WordPress
$targets = [
    'wp-file-manager', 'file-manager', 'advanced-file-manager',
    'filester', 'wp-file-manager-pro', 'real-file-manager',
    'filebird', 'wicked-folders', 'media-library-folders',
    'wp-media-folder', 'file-manager-advanced', 'simple-file-manager',
    'file-organizer', 'wp-file-organizer', 'fileorganizer',
    'smart-file-manager', 'file-manager-woocommerce', 'wp-filebase',
    'media-library-folder', 'folder-manager', 'wp-folders',
    'frontend-file-manager', 'wp-file-manager-backup', 'fm-backup'
];

// 🔍 Cari wp-config.php (naik ke atas maksimal 15 level)
$config = find_wp_config();
if (!$config) exit("❌ wp-config.php tidak ditemukan. Letakkan script di dalam folder WordPress.");

$root = dirname($config);
echo "📍 WordPress Root: <code>$root</code><br>";

// 1️⃣ Hardening wp-config.php
harden_config($config);

// 2️⃣ Hapus folder target
$plugins = "$root/wp-content/plugins";
if (!is_dir($plugins)) exit("❌ Folder /wp-content/plugins tidak ditemukan.");

echo "<br>🧹 Proses hapus plugin...<br>";
foreach ($targets as $plugin) {
    $path = "$plugins/$plugin";
    if (is_dir($path)) {
        echo delete_folder($path) 
            ? "✅ <b>$plugin</b> berhasil dihapus<br>" 
            : "❌ <b>$plugin</b> gagal (cek permission)<br>";
    }
}

echo "<br>✅ Selesai. <b>SEGERA HAPUS FILE SCRIPT INI DARI SERVER!</b>";

// ==================== FUNCTIONS ====================
function find_wp_config() {
    $dir = __DIR__;
    for ($i = 0; $i < 15; $i++) {
        if (file_exists("$dir/wp-config.php")) return "$dir/wp-config.php";
        $next = dirname($dir);
        if ($next === $dir) break; // Sudah di root server
        $dir = $next;
    }
    return false;
}

function harden_config($path) {
    $data = @file_get_contents($path);
    if (!$data) return;
    $defs = [
        "define('DISALLOW_FILE_EDIT', true);",
        "define('DISALLOW_FILE_MODS', true);"
    ];
    foreach ($defs as $d) {
        if (strpos($data, $d) === false) $data .= "\n$d";
    }
    @file_put_contents($path, $data);
    echo "🔒 wp-config.php di-hardening<br>";
}

function delete_folder($dir) {
    if (!is_dir($dir)) return false;
    @chmod($dir, 0777);
    $items = array_diff(scandir($dir), ['.', '..']);
    foreach ($items as $item) {
        $path = "$dir/$item";
        is_dir($path) ? delete_folder($path) : @unlink($path);
    }
    return @rmdir($dir);
}
?>